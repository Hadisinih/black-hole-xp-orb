package dev.hadi.blackholexp.mixin;

import dev.hadi.blackholexp.BlackHoleXpOrbClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.ExperienceOrbEntityRenderer;
import net.minecraft.client.render.entity.state.ExperienceOrbEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ExperienceOrbEntityRenderer.class)
public abstract class ExperienceOrbRendererMixin {
    private static final Identifier BLACK_HOLE_TEXTURE = Identifier.of(
            BlackHoleXpOrbClient.MOD_ID, "textures/entity/black_hole_orb.png");

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void blackholexp$renderBlackHole(ExperienceOrbEntityRenderState state,
            MatrixStack matrices, OrderedRenderCommandQueue queue,
            CameraRenderState cameraState, CallbackInfo ci) {
        float time = (System.currentTimeMillis() % 120000L) / 120000.0f * 360.0f;
        matrices.push();
        matrices.scale(0.42f, 0.42f, 0.42f);
        queue.submitCustom(matrices, RenderLayer.getEntityTranslucent(BLACK_HOLE_TEXTURE),
                (entry, vertices) -> {
                    renderSphere(entry, vertices);
                    renderAccretionDisk(entry, vertices, time);
                    renderAccretionDisk(entry, vertices, time + 180.0f);
                });
        matrices.pop();
        ci.cancel();
    }

    private static void renderSphere(MatrixStack.Entry entry, VertexConsumer out) {
        final int rings = 10, sectors = 16;
        for (int r = 0; r < rings; r++) {
            float v0 = (float) r / rings, v1 = (float) (r + 1) / rings;
            float a0 = (float) (Math.PI * v0), a1 = (float) (Math.PI * v1);
            for (int s = 0; s < sectors; s++) {
                float u0 = (float) s / sectors, u1 = (float) (s + 1) / sectors;
                float b0 = (float) (2.0 * Math.PI * u0), b1 = (float) (2.0 * Math.PI * u1);
                vertex(out, entry, point(a0,b0,0.48f), u0,v0, 2,1,8,255);
                vertex(out, entry, point(a1,b0,0.48f), u0,v1, 2,1,8,255);
                vertex(out, entry, point(a1,b1,0.48f), u1,v1, 2,1,8,255);
                vertex(out, entry, point(a0,b0,0.48f), u0,v0, 2,1,8,255);
                vertex(out, entry, point(a1,b1,0.48f), u1,v1, 2,1,8,255);
                vertex(out, entry, point(a0,b1,0.48f), u1,v0, 2,1,8,255);
            }
        }
    }

    private static void renderAccretionDisk(MatrixStack.Entry entry, VertexConsumer out, float rotation) {
        double rot = Math.toRadians(rotation);
        int segments = 48;
        for (int i = 0; i < segments; i++) {
            double a0 = (Math.PI * 2.0 * i / segments) + rot;
            double a1 = (Math.PI * 2.0 * (i + 1) / segments) + rot;
            float inner = 0.53f, outer = 0.88f;
            float y0 = 0.07f * (float)Math.sin(a0 * 3.0 + rot);
            float y1 = 0.07f * (float)Math.sin(a1 * 3.0 + rot);
            int red = 90 + (int)(70 * (0.5 + 0.5 * Math.sin(a0)));
            int blue = 220 + (int)(35 * (0.5 + 0.5 * Math.cos(a0)));
            float[] p1 = {(float)Math.cos(a0)*inner, y0, (float)Math.sin(a0)*inner};
            float[] p2 = {(float)Math.cos(a0)*outer, y0*1.5f, (float)Math.sin(a0)*outer};
            float[] p3 = {(float)Math.cos(a1)*outer, y1*1.5f, (float)Math.sin(a1)*outer};
            float[] p4 = {(float)Math.cos(a1)*inner, y1, (float)Math.sin(a1)*inner};
            vertex(out,entry,p1,0,0,red,30,blue,230);
            vertex(out,entry,p2,0,1,red,30,blue,110);
            vertex(out,entry,p3,1,1,red,30,blue,110);
            vertex(out,entry,p1,0,0,red,30,blue,230);
            vertex(out,entry,p3,1,1,red,30,blue,110);
            vertex(out,entry,p4,1,0,red,30,blue,230);
        }
    }

    private static float[] point(float a, float b, float radius) {
        return new float[] { radius * (float)Math.sin(a) * (float)Math.cos(b),
                radius * (float)Math.cos(a), radius * (float)Math.sin(a) * (float)Math.sin(b) };
    }

    private static void vertex(VertexConsumer out, MatrixStack.Entry entry, float[] p,
                               float u, float v, int r, int g, int b, int alpha) {
        out.vertex(entry, p[0], p[1], p[2])
                .color(r, g, b, alpha)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(0x00F000F0)
                .normal(entry, 0.0f, 1.0f, 0.0f);
    }
}
