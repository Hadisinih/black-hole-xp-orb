package dev.hadi.blackholexp;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class BlackHoleXpOrbClient implements ClientModInitializer {
    public static final String MOD_ID = "blackhole_xp_orb";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("Black Hole XP Orb renderer mixin initialized.");
    }
}
