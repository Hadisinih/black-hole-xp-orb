Black Hole XP Orb - Resource Pack Asset Preview

This folder contains the visual texture assets only. A normal resource pack cannot replace the XP orb renderer with a true custom 3D model. Use the Fabric mod project for renderer integration.
