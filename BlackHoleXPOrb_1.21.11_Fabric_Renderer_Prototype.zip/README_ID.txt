BLACK HOLE XP ORB - PROTOTIPE KODE RENDERER
Target: Minecraft Java 1.21.11, Fabric, Java 21

PENTING:
- Ini adalah source project, bukan file mod .jar siap pasang.
- Kode renderer menggunakan API Yarn 1.21.11 dan belum berhasil diuji build di lingkungan ini.
- Perlu dibuild dengan Gradle pada komputer/lingkungan yang punya Java 21 dan internet untuk mengunduh dependensi.
- Jangan masukkan folder proyek ke mods. Folder mods hanya menerima file .jar yang berhasil dibuild.

Struktur:
blackhole-xp-orb/  = proyek Gradle Fabric
assets/            = model OBJ dan aset sumber
resource-pack/     = metadata pack contoh

Jika build gagal, kirim teks error Gradle lengkap. Jangan hanya kirim tulisan "failed" karena itu setara diagnosis dokter dari foto sepatu.
