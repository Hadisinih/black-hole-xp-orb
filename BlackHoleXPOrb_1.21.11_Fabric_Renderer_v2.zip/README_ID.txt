BLACK HOLE XP ORB v3.
Isi: inti bola hitam, cincin akresi miring berputar, cincin lensa menghadap kamera,
glow, percikan ungu dan serpihan hitam yang mengorbit.
Ukuran/kecepatan: lihat bagian "Atur ukuran" di BlackHoleRenderer.java.
Belum diuji build. Kalau error, kirim teks error Gradle lengkap.
