BLACK HOLE XP ORB v4.
- Cincin akresi gaya v2 (diperbagus), ukuran lebih kecil, glow tidak lagi terpotong lantai
- Percikan ungu + serpihan hitam mengorbit
- Suara ambil XP diganti suara "disedot black hole" (assets/minecraft/sounds.json + sounds/blackhole_pickup.ogg)
Ukuran/kecepatan: bagian "Atur ukuran" di BlackHoleRenderer.java.
Belum diuji build. Kalau error, kirim teks error Gradle lengkap.
