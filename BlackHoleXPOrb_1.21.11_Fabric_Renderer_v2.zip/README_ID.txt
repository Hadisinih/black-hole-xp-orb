BLACK HOLE XP ORB v2 - renderer ditulis ulang.
Isi: inti bola hitam + cincin akresi miring berputar + glow menghadap kamera.
Ukuran/kecepatan bisa diatur di BlackHoleRenderer.java (bagian "Atur ukuran").
Belum diuji build. Kalau error, kirim teks error Gradle lengkap.
