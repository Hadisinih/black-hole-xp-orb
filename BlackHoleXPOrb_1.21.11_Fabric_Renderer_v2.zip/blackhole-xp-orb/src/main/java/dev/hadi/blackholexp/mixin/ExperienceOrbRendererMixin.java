package dev.hadi.blackholexp.mixin;

import dev.hadi.blackholexp.BlackHoleRenderer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.ExperienceOrbEntityRenderer;
import net.minecraft.client.render.entity.state.ExperienceOrbEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ExperienceOrbEntityRenderer.class)
public abstract class ExperienceOrbRendererMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void blackholexp$renderBlackHole(ExperienceOrbEntityRenderState state,
            MatrixStack matrices, OrderedRenderCommandQueue queue,
            CameraRenderState cameraState, CallbackInfo ci) {
        BlackHoleRenderer.render(matrices, queue, cameraState);
        ci.cancel();
    }
}
