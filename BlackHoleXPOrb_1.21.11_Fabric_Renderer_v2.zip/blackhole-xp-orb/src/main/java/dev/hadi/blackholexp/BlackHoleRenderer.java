package dev.hadi.blackholexp;

import java.util.Random;

import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/**
 * Black hole v3: inti bola, cincin akresi miring berputar (gaya v2),
 * glow, percikan ungu dan serpihan hitam yang mengorbit.
 */
public final class BlackHoleRenderer {
    private static Identifier tex(String n) {
        return Identifier.of(BlackHoleXpOrbClient.MOD_ID, "textures/entity/" + n + ".png");
    }
    private static final Identifier CORE  = tex("bh_core");
    private static final Identifier RING  = tex("bh_ring");
    private static final Identifier GLOW  = tex("bh_glow");
    private static final Identifier LENS  = tex("bh_lens");
    private static final Identifier SPARK = tex("bh_spark");
    private static final Identifier SHARD = tex("bh_shard");

    // ====== Atur ukuran di sini (satuan: blok) ======
    private static final float CORE_RADIUS = 0.09f;  // bola hitam
    private static final float RING_HALF   = 0.42f;  // setengah lebar cincin akresi
    private static final float GLOW_HALF   = 0.40f;  // setengah lebar glow
    private static final float LENS_HALF   = 0.19f;  // setengah lebar cincin putih (lensa)
    private static final float RING_TILT   = 26.0f;  // kemiringan cincin (derajat)
    private static final float SPIN_SPEED  = 70.0f;  // kecepatan putar cincin (derajat/detik)
    private static final float HEIGHT      = 0.30f;  // tinggi pusat dari tanah

    private static final int SPARKS = 18;
    private static final int SHARDS = 10;
    private static final float[] SP_PHASE = new float[SPARKS], SP_RADIUS = new float[SPARKS],
            SP_SPEED = new float[SPARKS], SP_Y = new float[SPARKS], SP_SIZE = new float[SPARKS];
    private static final float[] SH_PHASE = new float[SHARDS], SH_RADIUS = new float[SHARDS],
            SH_SPEED = new float[SHARDS], SH_Y = new float[SHARDS], SH_SIZE = new float[SHARDS];

    static {
        Random rnd = new Random(1337L);
        for (int i = 0; i < SPARKS; i++) {
            SP_PHASE[i] = rnd.nextFloat() * 6.2831f;
            SP_RADIUS[i] = 0.18f + rnd.nextFloat() * 0.30f;
            SP_SPEED[i] = (0.5f + rnd.nextFloat() * 0.9f) / SP_RADIUS[i];
            SP_Y[i] = (rnd.nextFloat() - 0.5f) * 0.06f;
            SP_SIZE[i] = 0.014f + rnd.nextFloat() * 0.020f;
        }
        for (int i = 0; i < SHARDS; i++) {
            SH_PHASE[i] = rnd.nextFloat() * 6.2831f;
            SH_RADIUS[i] = 0.20f + rnd.nextFloat() * 0.28f;
            SH_SPEED[i] = (0.4f + rnd.nextFloat() * 0.6f) / SH_RADIUS[i];
            SH_Y[i] = (rnd.nextFloat() - 0.5f) * 0.08f;
            SH_SIZE[i] = 0.020f + rnd.nextFloat() * 0.020f;
        }
    }

    private static final int FULL_BRIGHT = 0x00F000F0;

    private BlackHoleRenderer() {}

    public static void render(MatrixStack matrices, OrderedRenderCommandQueue queue, CameraRenderState camera) {
        float seconds = (System.nanoTime() / 1_000_000L % 3_600_000L) / 1000.0f;

        matrices.push();
        matrices.translate(0.0, HEIGHT, 0.0);

        // 1) Glow (menghadap kamera)
        billboard(matrices, queue, camera, GLOW, true, GLOW_HALF, 210);

        // 1b) Cincin putih tipis (menghadap kamera): efek menyerap cahaya
        billboard(matrices, queue, camera, LENS, true, LENS_HALF, 255);

        // 2) Inti hitam
        queue.submitCustom(matrices, RenderLayers.entityTranslucent(CORE),
                (entry, out) -> sphere(entry, out, CORE_RADIUS));

        // 3) Cincin akresi: miring lalu berputar
        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(RING_TILT));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(seconds * SPIN_SPEED));
        queue.submitCustom(matrices, RenderLayers.entityTranslucentEmissive(RING),
                (entry, out) -> quadXZ(entry, out, RING_HALF, 255, 255, 255, 255));
        matrices.pop();

        // 4) Serpihan hitam dan percikan ungu yang mengorbit (pada bidang cincin)
        for (int i = 0; i < SHARDS; i++) {
            float ang = SH_PHASE[i] + seconds * SH_SPEED[i];
            orbitBillboard(matrices, queue, camera, SHARD, false,
                    (float) Math.cos(ang) * SH_RADIUS[i], SH_Y[i], (float) Math.sin(ang) * SH_RADIUS[i],
                    SH_SIZE[i], 255);
        }
        for (int i = 0; i < SPARKS; i++) {
            float ang = SP_PHASE[i] + seconds * SP_SPEED[i];
            int alpha = (int) (170 + 85 * Math.sin(seconds * 3.0f + SP_PHASE[i] * 5.0f));
            orbitBillboard(matrices, queue, camera, SPARK, true,
                    (float) Math.cos(ang) * SP_RADIUS[i], SP_Y[i], (float) Math.sin(ang) * SP_RADIUS[i],
                    SP_SIZE[i], Math.max(0, Math.min(255, alpha)));
        }

        matrices.pop();
    }

    private static void billboard(MatrixStack matrices, OrderedRenderCommandQueue queue, CameraRenderState camera,
                                  Identifier texture, boolean emissive, float half, int alpha) {
        matrices.push();
        matrices.multiply(camera.orientation);
        if (emissive) {
            queue.submitCustom(matrices, RenderLayers.entityTranslucentEmissive(texture),
                    (entry, out) -> quadXY(entry, out, half, 255, 255, 255, alpha));
        } else {
            queue.submitCustom(matrices, RenderLayers.entityTranslucent(texture),
                    (entry, out) -> quadXY(entry, out, half, 255, 255, 255, alpha));
        }
        matrices.pop();
    }

    private static void orbitBillboard(MatrixStack matrices, OrderedRenderCommandQueue queue, CameraRenderState camera,
                                       Identifier texture, boolean emissive,
                                       float x, float y, float z, float half, int alpha) {
        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(RING_TILT));
        matrices.translate(x, y, z);
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-RING_TILT));
        billboard(matrices, queue, camera, texture, emissive, half, alpha);
        matrices.pop();
    }

    private static void sphere(MatrixStack.Entry e, VertexConsumer out, float radius) {
        final int rings = 12, sectors = 20;
        for (int r = 0; r < rings; r++) {
            float a0 = (float) (Math.PI * r / rings), a1 = (float) (Math.PI * (r + 1) / rings);
            for (int s = 0; s < sectors; s++) {
                float b0 = (float) (2.0 * Math.PI * s / sectors), b1 = (float) (2.0 * Math.PI * (s + 1) / sectors);
                float[] p00 = pt(a0, b0, radius), p10 = pt(a1, b0, radius);
                float[] p11 = pt(a1, b1, radius), p01 = pt(a0, b1, radius);
                // dua sisi supaya tidak hilang karena culling
                tri(e, out, p00, p10, p11);
                tri(e, out, p00, p11, p01);
                tri(e, out, p00, p11, p10);
                tri(e, out, p00, p01, p11);
            }
        }
    }

    private static void tri(MatrixStack.Entry e, VertexConsumer out, float[] a, float[] b, float[] c) {
        v(e, out, a[0], a[1], a[2], 0.5f, 0.5f, 255, 255, 255, 255);
        v(e, out, b[0], b[1], b[2], 0.5f, 0.5f, 255, 255, 255, 255);
        v(e, out, c[0], c[1], c[2], 0.5f, 0.5f, 255, 255, 255, 255);
    }

    private static float[] pt(float a, float b, float r) {
        return new float[] {
                r * (float) Math.sin(a) * (float) Math.cos(b),
                r * (float) Math.cos(a),
                r * (float) Math.sin(a) * (float) Math.sin(b) };
    }

    /** Kotak di bidang XY (billboard). */
    private static void quadXY(MatrixStack.Entry e, VertexConsumer out, float h, int r, int g, int b, int a) {
        quad(e, out, new float[][] { {-h, -h, 0}, {-h, h, 0}, {h, h, 0}, {h, -h, 0} }, r, g, b, a);
    }

    /** Kotak di bidang XZ (cincin akresi). */
    private static void quadXZ(MatrixStack.Entry e, VertexConsumer out, float h, int r, int g, int b, int a) {
        quad(e, out, new float[][] { {-h, 0, -h}, {-h, 0, h}, {h, 0, h}, {h, 0, -h} }, r, g, b, a);
    }

    private static void quad(MatrixStack.Entry e, VertexConsumer out, float[][] p, int r, int g, int b, int a) {
        float[][] uv = { {0, 0}, {0, 1}, {1, 1}, {1, 0} };
        for (int i = 0; i < 4; i++) v(e, out, p[i][0], p[i][1], p[i][2], uv[i][0], uv[i][1], r, g, b, a);
        for (int i = 3; i >= 0; i--) v(e, out, p[i][0], p[i][1], p[i][2], uv[i][0], uv[i][1], r, g, b, a);
    }

    private static void v(MatrixStack.Entry e, VertexConsumer out, float x, float y, float z,
                          float u, float vv, int r, int g, int b, int a) {
        out.vertex(e, x, y, z)
                .color(r, g, b, a)
                .texture(u, vv)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(FULL_BRIGHT)
                .normal(e, 0.0f, 1.0f, 0.0f);
    }
}
