package dev.hadi.blackholexp;

import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/** Menggambar black hole: inti (bola), cincin akresi (miring + berputar), glow (selalu menghadap kamera). */
public final class BlackHoleRenderer {
    private static final Identifier CORE = Identifier.of(BlackHoleXpOrbClient.MOD_ID, "textures/entity/bh_core.png");
    private static final Identifier RING = Identifier.of(BlackHoleXpOrbClient.MOD_ID, "textures/entity/bh_ring.png");
    private static final Identifier GLOW = Identifier.of(BlackHoleXpOrbClient.MOD_ID, "textures/entity/bh_glow.png");

    // ====== Atur ukuran di sini (satuan: blok) ======
    private static final float CORE_RADIUS = 0.14f;  // bola hitam
    private static final float RING_HALF   = 0.50f;  // setengah lebar cincin
    private static final float GLOW_HALF   = 0.60f;  // setengah lebar glow
    private static final float RING_TILT   = 22.0f;  // kemiringan cincin (derajat)
    private static final float SPIN_SPEED  = 70.0f;  // kecepatan putar (derajat/detik)

    private static final int FULL_BRIGHT = 0x00F000F0;

    private BlackHoleRenderer() {}

    public static void render(MatrixStack matrices, OrderedRenderCommandQueue queue, CameraRenderState camera) {
        float seconds = (System.nanoTime() / 1_000_000L % 3_600_000L) / 1000.0f;

        matrices.push();
        matrices.translate(0.0, 0.15, 0.0);

        // 1) Glow: selalu menghadap kamera
        matrices.push();
        matrices.multiply(camera.orientation);
        queue.submitCustom(matrices, RenderLayers.entityTranslucentEmissive(GLOW),
                (entry, out) -> quadXY(entry, out, GLOW_HALF, 255, 255, 255, 230));
        matrices.pop();

        // 2) Inti hitam
        queue.submitCustom(matrices, RenderLayers.entityTranslucent(CORE),
                (entry, out) -> sphere(entry, out, CORE_RADIUS));

        // 3) Cincin akresi: miring lalu berputar
        matrices.push();
        matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(RING_TILT));
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(seconds * SPIN_SPEED));
        queue.submitCustom(matrices, RenderLayers.entityTranslucentEmissive(RING),
                (entry, out) -> quadXZ(entry, out, RING_HALF, 255, 255, 255, 255));
        matrices.pop();

        matrices.pop();
    }

    private static void sphere(MatrixStack.Entry e, VertexConsumer out, float radius) {
        final int rings = 12, sectors = 20;
        for (int r = 0; r < rings; r++) {
            float a0 = (float) (Math.PI * r / rings), a1 = (float) (Math.PI * (r + 1) / rings);
            for (int s = 0; s < sectors; s++) {
                float b0 = (float) (2.0 * Math.PI * s / sectors), b1 = (float) (2.0 * Math.PI * (s + 1) / sectors);
                float[] p00 = pt(a0, b0, radius), p10 = pt(a1, b0, radius);
                float[] p11 = pt(a1, b1, radius), p01 = pt(a0, b1, radius);
                // dua sisi supaya tidak hilang karena culling
                tri(e, out, p00, p10, p11);
                tri(e, out, p00, p11, p01);
                tri(e, out, p00, p11, p10);
                tri(e, out, p00, p01, p11);
            }
        }
    }

    private static void tri(MatrixStack.Entry e, VertexConsumer out, float[] a, float[] b, float[] c) {
        v(e, out, a[0], a[1], a[2], 0.5f, 0.5f, 255, 255, 255, 255);
        v(e, out, b[0], b[1], b[2], 0.5f, 0.5f, 255, 255, 255, 255);
        v(e, out, c[0], c[1], c[2], 0.5f, 0.5f, 255, 255, 255, 255);
    }

    private static float[] pt(float a, float b, float r) {
        return new float[] {
                r * (float) Math.sin(a) * (float) Math.cos(b),
                r * (float) Math.cos(a),
                r * (float) Math.sin(a) * (float) Math.sin(b) };
    }

    /** Kotak di bidang XY (dipakai untuk glow yang menghadap kamera). */
    private static void quadXY(MatrixStack.Entry e, VertexConsumer out, float h, int r, int g, int b, int a) {
        quad(e, out, new float[][] {
                {-h, -h, 0}, {-h, h, 0}, {h, h, 0}, {h, -h, 0} }, r, g, b, a);
    }

    /** Kotak di bidang XZ (dipakai untuk cincin). */
    private static void quadXZ(MatrixStack.Entry e, VertexConsumer out, float h, int r, int g, int b, int a) {
        quad(e, out, new float[][] {
                {-h, 0, -h}, {-h, 0, h}, {h, 0, h}, {h, 0, -h} }, r, g, b, a);
    }

    private static void quad(MatrixStack.Entry e, VertexConsumer out, float[][] p, int r, int g, int b, int a) {
        float[][] uv = { {0, 0}, {0, 1}, {1, 1}, {1, 0} };
        // sisi depan
        for (int i = 0; i < 4; i++) v(e, out, p[i][0], p[i][1], p[i][2], uv[i][0], uv[i][1], r, g, b, a);
        // sisi belakang (urutan dibalik)
        for (int i = 3; i >= 0; i--) v(e, out, p[i][0], p[i][1], p[i][2], uv[i][0], uv[i][1], r, g, b, a);
    }

    private static void v(MatrixStack.Entry e, VertexConsumer out, float x, float y, float z,
                          float u, float vv, int r, int g, int b, int a) {
        out.vertex(e, x, y, z)
                .color(r, g, b, a)
                .texture(u, vv)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(FULL_BRIGHT)
                .normal(e, 0.0f, 1.0f, 0.0f);
    }
}
